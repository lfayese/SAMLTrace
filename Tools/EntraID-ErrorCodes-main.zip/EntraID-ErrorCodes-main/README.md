# EntraID-ErrorCodes

Entra ID (Azure AD) error codes as JSON, CSV and Sentinel watchlist ARM template.

You will find more information on how to use this data in [this blog post](https://cloudbrothers.info/en/entra-id-azure-ad-signin-errors/).

If you still have unresolved `ResultDescription` in the `SignInLogs` with this data, feel free to create a pull request or send me the error code and I will add it.

